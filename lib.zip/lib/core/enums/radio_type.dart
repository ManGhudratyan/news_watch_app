enum RadioType { mediaReporter, visitor }
