// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Russian (`ru`).
class AppLocalizationsRu extends AppLocalizations {
  AppLocalizationsRu([String locale = 'ru']) : super(locale);

  @override
  String get btnSignUp => 'Sign Up';

  @override
  String get btnSignIn => 'Sign in';

  @override
  String get txtUsername => 'Username';

  @override
  String get txtEmail => 'Email';

  @override
  String get txtPhoneNumber => 'Phone number';

  @override
  String get txtPassword => 'Password';

  @override
  String get txtRepeatPassword => 'Repeat password';

  @override
  String get txtMediaReporter => 'Media Reporter';

  @override
  String get txtVisitor => 'Visitor';

  @override
  String get txtHaveAnAccount => 'Have an account?';

  @override
  String get txtIamA => 'I am a';

  @override
  String get txtForgotPassword => 'Forgot password?';

  @override
  String get txtDontHaveAnAccount => 'Dont have an account?';

  @override
  String get txtRegister => 'Register';

  @override
  String get txtEnterYourEmail => 'Enter your email';

  @override
  String get txtVerificationCode => 'Verification Code';

  @override
  String get txtEnterNewPassword => 'Enter new password';

  @override
  String get txtReEnterYourPassword => 'Re Enter your Password';

  @override
  String get txtPleaseFillAllFields => 'Please fill all fields';

  @override
  String get txtPasswordsDoNotMatch => 'Passwords do not match';

  @override
  String get txtOrSignInWith => 'or sign in with';

  @override
  String get txtAppBarSettings => 'Settings';

  @override
  String get txtProfile => 'Profile';

  @override
  String get txtMyWallet => 'My Wallet';

  @override
  String get txtMyPost => 'My Post';

  @override
  String get txtBoostYourPost => 'Boost Your Post';

  @override
  String get txtNotifications => 'Notifications';

  @override
  String get txtTermsAndConditions => 'Terms and Conditions';

  @override
  String get txtAbout => 'About';

  @override
  String get txtWatchAdsAndEarn => 'Watch Ads & Earn';

  @override
  String get txtReferAndEarn => 'Refer and Earn';

  @override
  String get txtLogOut => 'Log out';

  @override
  String get txtFIrstName => 'First name';

  @override
  String get txtLastName => 'Last name';

  @override
  String get txtMyProfile => 'My profile';

  @override
  String get txtChangeProfilePhoto => 'Change profile photo';

  @override
  String get txtUploadMediaDocument => 'Upload Media Document';

  @override
  String get txtBrowseFile => 'Browse file';

  @override
  String get txtAddPostImages => 'Add post images';

  @override
  String get txtAddHeading => 'Add Heading';

  @override
  String get txtAddTag => 'Add Tag';

  @override
  String get txtCategory => 'Category';

  @override
  String get txtVideoLink => 'Add Video Link';

  @override
  String get txtSponsored => 'Sponsored';

  @override
  String get txtDescription => 'Description';

  @override
  String get txtUpdateButton => 'Update';

  @override
  String get txtLoggedOutSuccessfully => 'Logged out successfully';
}
