// ignore_for_file: depend_on_referenced_packages

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';
import 'package:news_watch_app/data/models/add_post/add_post_model.dart';
import 'package:news_watch_app/domain/repositories/add_post_repository.dart';

part 'add_post_state.dart';

class AddPostCubit extends Cubit<AddPostState> {
  final AddPostRepository addPostRepository;
  List<AddPostModel> posts = [];
  AddPostCubit(this.addPostRepository) : super(AddPostState());

  Future<void> addNewPost(AddPostModel model) async {
    emit(state.copyWith(loading: true));
    try {
      await addPostRepository.addPosts(model);
      posts = [model, ...posts];
      emit(state.copyWith(posts: posts));
      final updatedPosts = await addPostRepository.getPosts(
        userId: model.userId,
      );
  //  emit(state.copyWith(posts: posts));
    } catch (e) {
      // emit(AddPostFailure(e.toString()));?
    }
  }

  Future<void> getPosts(String userId) async {
    emit(state.copyWith(loading: true));
    try {
      final updatedPosts = await addPostRepository.getPosts(userId: userId);
      emit(state.copyWith(posts: updatedPosts));
    } catch (e) {
      // emit(AddPostFailure(e.toString()));
    }
  }
}
