part of 'add_post_cubit.dart';

// @immutable
// sealed class AddPostState {}

// final class AddPostInitial extends AddPostState {}

// class AddPostLoading extends AddPostState {}

// class AddPostLoaded extends AddPostState {
//   final List<AddPostModel> posts;
//   AddPostLoaded(this.posts);
// }

// class AddPostFailure extends AddPostState {
//   final String error;
//   AddPostFailure(this.error);
// }

// class AddPostSuccess extends AddPostState {}

class AddPostState extends Equatable {
  final List<AddPostModel>? posts;
  final bool loading;

  const AddPostState({ this.posts, this.loading = true});

  AddPostState copyWith({List<AddPostModel>? posts, bool? loading}) {
    return AddPostState(
      posts: posts ?? this.posts,
      loading: loading ?? this.loading,
    );
  }

  @override
  List<Object?> get props => [posts,loading];
}
