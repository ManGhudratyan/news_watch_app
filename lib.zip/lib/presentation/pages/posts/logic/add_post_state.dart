// part of 'add_post_bloc.dart';

// @immutable
// sealed class AddPostState {}

// final class AddPostInitial extends AddPostState {}

// class AddPostLoading extends AddPostState {}

// class AddPostLoaded extends AddPostState {
//   final List<AddPostModel> posts;
//   AddPostLoaded(this.posts);
// }

// class AddPostFailure extends AddPostState {
//   final String error;
//   AddPostFailure(this.error);
// }

part of 'add_post_bloc.dart';

@immutable
abstract class AddPostState {}

class AddPostInitial extends AddPostState {}

class AddPostLoading extends AddPostState {}

class AddPostLoaded extends AddPostState {
  final List<AddPostModel> posts;
  AddPostLoaded(this.posts);
}

class AddPostFailure extends AddPostState {
  final String error;
  AddPostFailure(this.error);
}

// ✅ New state for success after adding a post
class AddPostSuccess extends AddPostState {}